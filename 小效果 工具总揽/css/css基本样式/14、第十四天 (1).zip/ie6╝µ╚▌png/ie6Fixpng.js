// JavaScript Document
  DD_belatedPNG.fix('*');